package com.simactivation.Enum;

public enum Id_Type {
	
   AADHAR,PANCARD,PASSPORT,VOTERID,DRIVINGLICENCE
   
}
