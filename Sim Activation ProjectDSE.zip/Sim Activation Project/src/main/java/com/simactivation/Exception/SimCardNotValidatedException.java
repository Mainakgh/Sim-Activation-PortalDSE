package com.simactivation.Exception;

public class SimCardNotValidatedException extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SimCardNotValidatedException(String msg) {
		super(msg);
	}
	

}
